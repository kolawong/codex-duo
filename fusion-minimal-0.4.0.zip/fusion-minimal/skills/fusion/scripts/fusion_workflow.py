#!/usr/bin/env python3
"""Local saved-default workflow adapter; never launches a model or task command."""
import argparse
import json
from pathlib import Path
from fusion_service import FusionService
from fusion_selection import SelectionError


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='command', required=True)
    for command in ('defaults', 'begin'):
        sub = commands.add_parser(command)
        sub.add_argument('--project-root', type=Path, required=True)
        if command == 'begin':
            sub.add_argument('--task', type=Path, required=True)
            sub.add_argument('--invocation', choices=['automatic', 'explicit'], required=True)
    args = parser.parse_args()
    try:
        if not args.project_root.is_absolute() or not args.project_root.is_dir() or args.project_root.is_symlink():
            raise SelectionError('invalid_project', '项目必须是现有的绝对路径目录。')
        service = FusionService(args.project_root / '.fusion')
        if args.command == 'defaults':
            result = service.defaults(str(args.project_root))
        else:
            result = service.begin({'project_root': str(args.project_root),
                'task': json.loads(args.task.read_text()), 'invocation': args.invocation})
        print(json.dumps(result, ensure_ascii=False))
        return 0
    except (SelectionError, OSError, ValueError) as exc:
        print(json.dumps({'state': 'blocked', 'execution_started': False,
                          'error': {'code': getattr(exc, 'code', 'local_error'), 'message': str(exc)}}, ensure_ascii=False))
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
