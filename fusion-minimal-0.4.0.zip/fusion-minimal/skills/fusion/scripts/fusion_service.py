"""Shared application service for HTTP, MCP settings and the MCP App."""
import json
from pathlib import Path
from fusion_selection import (SelectionError, SelectionStore, read_catalog, default_selection,
                              presets, prepare_handoff, digest, validate_selection, saved_workflow)


class FusionService:
    def __init__(self, directory, catalog_loader=read_catalog):
        self.store = SelectionStore(directory)
        self.catalog_loader = catalog_loader
        self.template = json.loads((Path(__file__).parent.parent / 'templates/task.json').read_text())

    def state(self):
        try:
            catalog = self.catalog_loader()
        except SelectionError as exc:
            return {'catalog': None, 'error': {'code': exc.code, 'message': str(exc)},
                    'task_template': self.template}
        saved = self.store.read(catalog)
        return {'catalog': catalog, 'presets': presets(catalog), 'default': default_selection(catalog),
                'saved': saved, 'workflow': saved_workflow(saved['document']), 'task_template': self.template,
                'project_root': str(self.store.directory.parent.resolve()),
                'storage_path': str(self.store.path), 'current_thread_model': 'unknown',
                'native_model_switch': False, 'execution_started': False}

    def save(self, body):
        return self.store.save(body.get('selection'), self.catalog_loader(), body.get('expected_revision'),
                               body.get('workflow'))

    def check_project(self, project_root):
        if (not isinstance(project_root, str) or not Path(project_root).is_absolute()
                or Path(project_root).resolve() != self.store.directory.parent.resolve()):
            raise SelectionError('project_mismatch', '此配置仅用于面板显示的项目，不能自动应用到其他项目。', 409)

    def defaults(self, project_root):
        """Compact model-visible entry point. Reading does not create files."""
        self.check_project(project_root)
        saved = self.store.read(self.catalog_loader())
        if saved['error']:
            raise SelectionError('saved_config_invalid', saved['error']['message'], 409)
        if not saved['document']:
            return {'configured': False, 'state': 'setup_required', 'setup_tool': 'fusion.open',
                    'execution_started': False}
        workflow = saved_workflow(saved['document'])
        return {'configured': True, 'state': 'ready', 'project_root': project_root,
                'revision': saved['revision'], 'workflow': workflow,
                'worker': saved['document']['selection']['worker'],
                'coordinator': {'mode': workflow['coordinator_mode'],
                    'selected_model': saved['document']['selection']['coordinator']
                    if workflow['coordinator_mode'] == 'selected_model' else None},
                'next_tool': 'fusion.begin', 'execution_started': False,
                'instructions': 'Use these saved settings for the authorized task. Do not reopen settings, '
                    'ask for JSON or handoff paths, or request the same approval again. '
                    'Discover a native worker tool before dispatch; this MCP server does not launch models.'}

    def begin(self, body):
        """Resolve current defaults and create the internal task snapshot in one step."""
        self.check_project(body.get('project_root'))
        with self.store.lock:
            catalog = self.catalog_loader()
            saved = self.store.read(catalog)
            if not saved['document']:
                raise SelectionError('setup_required', '请先完成一次 Fusion 配置。已有无效配置时请恢复。', 409)
            workflow = saved_workflow(saved['document'])
            invocation = body.get('invocation')
            if invocation not in ('automatic', 'explicit'):
                raise SelectionError('invalid_invocation', '请说明由项目默认流程还是用户明确要求启用。')
            if invocation == 'automatic' and workflow['activation'] != 'automatic_project':
                raise SelectionError('manual_mode', '当前为手动模式，仅在用户要求使用 Fusion 时启用。', 409)
            prepared = prepare_handoff(body.get('task'), saved['document']['selection'], catalog,
                                       self.store.directory / 'handoffs', saved['revision'], workflow)
            plan = self.execution_plan(prepared['id'])
            return {**plan, 'handoff_path': prepared['path'], 'created': prepared['created'],
                    'evidence_root': str(self.store.directory / 'runs' / prepared['id']),
                    'task_path': str(Path(prepared['path']) / 'task.json')}

    def prepare(self, body):
        with self.store.lock:
            catalog = self.catalog_loader()
            saved = self.store.read(catalog)
            if not saved['document']:
                raise SelectionError('save_required', '先保存一份有效配置，再生成交接包。', 409)
            if body.get('expected_revision') != saved['revision']:
                raise SelectionError('revision_conflict', '保存版本已变化，请恢复已保存配置后重试。', 409)
            return prepare_handoff(body.get('task'), saved['document']['selection'], catalog,
                                   self.store.directory / 'handoffs', saved['revision'])

    def settings_read(self):
        state = self.state()
        if state['catalog'] is None:
            raise SelectionError('catalog_unavailable', state['error']['message'], 503)
        if state['saved']['error']:
            raise SelectionError('saved_config_invalid', '请打开模型面板恢复损坏或过期配置。', 409)
        selection = state['saved']['document']['selection'] if state['saved']['document'] else state['default']
        pairs = [m['id'] + ' / ' + e for m in state['catalog']['models'] for e in m['efforts']]
        properties = {role: {'type': 'string', 'title': title, 'enum': pairs,
            'description': '保存后持续使用，直到主动修改。保存本身不启动任务。'}
            for role, title in [('worker', '执行模型与强度'), ('coordinator', '高级：指定主控模型与强度')]}
        properties.update({
            'activation': {'type': 'string', 'title': '使用方式',
                'enum': ['automatic_project', 'manual'],
                'description': 'automatic_project：本项目开发任务自动使用；manual：明确说用 Fusion 时使用。'},
            'coordinator_mode': {'type': 'string', 'title': '主控方式',
                'enum': ['current_thread', 'selected_model'],
                'description': 'current_thread：当前聊天规划验收；selected_model：另开聊天使用指定主控。'},
            'max_worker_turns': {'type': 'string', 'title': '每项任务最多执行轮数',
                'enum': [str(n) for n in range(1, 11)], 'description': '包括首次执行和修正，达到上限停止。'}})
        return {'schema': {'type': 'object', 'properties': properties},
                'values': self.settings_values(selection, state['workflow']),
                'layout': [{'kind': 'group', 'title': 'Fusion · 保存一次，持续使用', 'items': [
                    {'kind': 'property', 'property': r} for r in properties] + [
                    {'kind': 'tool', 'tool': 'fusion.open', 'title': '打开模型面板',
                     'description': '查看或更新已保存配置。'}]}]}

    @staticmethod
    def settings_values(selection, workflow):
        return {**{r: selection[r]['model'] + ' / ' + selection[r]['reasoning_effort'] for r in selection},
                **workflow, 'max_worker_turns': str(workflow['max_worker_turns'])}

    def settings_update(self, changes):
        with self.store.lock:
            catalog = self.catalog_loader()
            saved = self.store.read(catalog)
            if saved['error']:
                raise SelectionError('saved_config_invalid', '请先在模型面板恢复配置。', 409)
            selection = saved['document']['selection'] if saved['document'] else default_selection(catalog)
            workflow = saved_workflow(saved['document'])
            for role, pair in changes.items():
                if role in workflow:
                    if role == 'max_worker_turns':
                        if not isinstance(pair, str) or not pair.isascii() or not pair.isdigit():
                            raise SelectionError('invalid_workflow', '执行轮数必须为 1 到 10。')
                        pair = int(pair)
                    workflow[role] = pair
                    continue
                if role not in ('coordinator', 'worker') or not isinstance(pair, str) or pair.count(' / ') != 1:
                    raise SelectionError('invalid_selection', '设置必须为有效的模型 / 推理强度组合。')
                model, effort = pair.split(' / ')
                selection[role] = {'model': model, 'reasoning_effort': effort}
            self.store.save(selection, catalog, saved['revision'], workflow)
            return {'values': self.settings_values(selection, workflow)}

    def execution_plan(self, identifier):
        # IDs, never caller-supplied paths. Reject linked or tampered snapshots.
        import re
        if not isinstance(identifier, str) or not re.fullmatch('[a-f0-9]{24}', identifier):
            raise SelectionError('invalid_handoff', '交接 ID 格式无效。')
        root = self.store.directory / 'handoffs'
        target = root / identifier
        paths = [self.store.directory, root, target, target / 'handoff.json', target / 'task.json',
                 target / 'config', target / 'config/project.toml', target / 'config/fusion_worker.toml',
                 target / 'README.md']
        if any(p.is_symlink() for p in paths):
            raise SelectionError('unsafe_storage', '交接包不能包含符号链接。', 409)
        try:
            manifest = json.loads((target / 'handoff.json').read_text())
            catalog = self.catalog_loader()
            payload = {k: manifest[k] for k in ('schema_version', 'task', 'selection', 'catalog_fingerprint', 'selection_revision')}
            if 'workflow' in manifest:
                payload['workflow'] = manifest['workflow']
            if digest(payload)[:24] != identifier or manifest.get('handoff_id') != identifier:
                raise ValueError('digest')
            if catalog['fingerprint'] != manifest['catalog_fingerprint']:
                raise SelectionError('catalog_changed', '模型目录已变化，请重新生成交接包。', 409)
            validate_selection(manifest['selection'], catalog)
            # Existing path: verify every immutable artifact, never modify it.
            result = prepare_handoff(manifest['task'], manifest['selection'], catalog, root,
                                     manifest['selection_revision'], manifest.get('workflow'))
            if result['created']:
                raise ValueError('missing snapshot')
        except (OSError, KeyError, TypeError, ValueError) as exc:
            if isinstance(exc, SelectionError):
                raise
            raise SelectionError('invalid_handoff', '交接包不存在或已损坏。', 409) from exc
        if 'workflow' in manifest:
            workflow = saved_workflow(manifest)
            current = workflow['coordinator_mode'] == 'current_thread'
            return {'schema_version': 1, 'handoff_id': identifier,
                    'state': 'ready_for_native_worker' if current else 'new_coordinator_required',
                    'execution_started': False, 'project_root': str(self.store.directory.parent.resolve()),
                    'coordinator': {'mode': workflow['coordinator_mode'], 'requires_new_task': not current,
                        'selected_model': None if current else manifest['selection']['coordinator']},
                    'worker': {**manifest['worker_spawn_parameters'], 'fork_context': False},
                    'max_worker_turns': workflow['max_worker_turns'], 'task': manifest['task'],
                    'authorization': 'Use the current user task and saved settings; honor all task scope limits.',
                    'verification': 'Use fusion.py verify, then independently review changes and rerun tests.',
                    'adapter': 'The current chat orchestrates one native worker. No model has started. '
                        'Do not claim execution until a native worker receipt exists. '
                        'Never substitute a model or create a new chat without the user requesting one.'}
        return {'schema_version': 1, 'handoff_id': identifier, 'state': 'approval_required',
                'execution_started': False, 'applies_to_current_thread': False,
                'coordinator': {'requires_new_task': True, **manifest['selection']['coordinator']},
                'worker': manifest['worker_spawn_parameters'], 'task': manifest['task'],
                'verification': 'Use fusion.py verify with task.json and worker result; coordinator independently reviews diff and reruns tests.',
                'required_before_execution': ['Explicit user approval for this task and model pair',
                    'Create a new coordinator task with the selected model and effort',
                    'Verify the actual coordinator settings before spawning one worker'],
                'adapter': 'Declarative handoff only; this server implements no model launcher or thread-switch API.'}
