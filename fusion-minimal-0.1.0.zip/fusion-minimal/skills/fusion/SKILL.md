---
name: fusion
description: Use when the user asks for a Fusion workflow with a Sol coordinator and a bounded Luna worker, compact handoff, diff, test evidence, and explicit acceptance. Supports an offline demo without model calls.
---

Keep the main thread focused on decisions and acceptance. The main Sol agent plans,
the separately configured fusion_worker executes, and the same Sol agent verifies.

## Approval boundary

The prototype is offline by default. Do not launch a worker merely because this
Skill was invoked. A real dual-model run requires explicit user approval naming
the worker model, reasoning effort, task scope, and maximum worker turns. Do not
enable Astra, silently substitute a model, or start a second reviewer model.
Report installation, project trust, or configuration changes before requesting
their approval. Do not modify global settings or install/trust Hooks automatically.

## Prepare

Check the current client's model catalog and native custom-agent support. Confirm
the current coordinator is gpt-6.1-sol/high and fusion_worker resolves to the
approved model. If this host cannot select a named custom agent, report that
blocker; do not turn a generic spawn into an unverified model selection.

Copy templates/task.json into a task-specific local artifact directory and fill
its id, goal, allowed_paths, acceptance criteria, and test argv. Give the worker
only that compact specification and necessary file references. Use a fresh
context when supported. Do not forward the parent history or full tool logs.

Custom agent TOML files are companion project configuration, not portable plugin
components. Use the supplied .codex/agents/fusion_worker.toml only within the
approved project. Never overwrite an existing custom agent or AGENTS.md.

## Execute after approval

Use one native fusion_worker at a time. Pass a bounded task; wait for its result.
The worker saves result.json, diff, and logs locally. It returns only status,
summary, changed paths, artifact references, test exit codes, and blockers.
Limit corrections to the approved turn budget. When exhausted, report blockers.
Keep meaningful progress updates brief; do not suppress failures or approval needs.

## Verify

Read references/contract.md. Use scripts/fusion.py verify with the task JSON,
result JSON, and artifact root. That gate checks identity, scope, hashes, and
test evidence. It does not prove semantic correctness: the Sol coordinator must
inspect the diff, confirm actual changed files, rerun appropriate checks, and
compare behavior with the acceptance criteria. Reject missing evidence or an
unresolved blocker. Describe the outcome and limitations in at most 12 lines.

## Offline demonstration

Run `python3 <skill-dir>/scripts/fusion.py demo --out <new-local-directory>`.
This uses a deterministic fixture edit and unittest, never calls a model, and
refuses to overwrite a directory. Full logs stay in the output directory.
Do not describe that fixture as a real Luna run or cost-saving measurement.
